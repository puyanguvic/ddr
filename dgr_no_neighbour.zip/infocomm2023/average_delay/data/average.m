clc
clear all
% X = load('abilene/dgr-1mbps.txt');
% X = load('abilene/dgr-2mbps.txt');
% X = load('abilene/dgr-3mbps.txt');
% X = load('abilene/dgr-4mbps.txt');
% X = load('abilene/dgr-5mbps.txt');
% X = load('abilene/dgr-6mbps.txt');
% X = load('abilene/dgr-7mbps.txt');
% X = load('abilene/dgr-8mbps.txt');
% X = load('abilene/dgr-9mbps.txt');
% X = load('abilene/dgr-10mbps.txt');
% X = load('abilene/ospf-1mbps.txt');
% X = load('abilene/ospf-2mbps.txt');
% X = load('abilene/ospf-3mbps.txt');
% X = load('abilene/ospf-4mbps.txt');
% X = load('abilene/ospf-5mbps.txt');
% X = load('abilene/ospf-6mbps.txt');
% X = load('abilene/ospf-7mbps.txt');
% X = load('abilene/ospf-8mbps.txt');
% X = load('abilene/ospf-9mbps.txt');
% X = load('abilene/ospf-10mbps.txt');
M = mean(X)