clc;
clear all;
X = load ('abliene_delay.txt');
x = X(:);
h = cdfplot(x);
hold on
