clc;
clear all;
X = load ('abilene/dgr_abilene.txt');
Y = load ('abilene/ospf-abilene.txt')
h1 = cdfplot(X);
hold on
y = Y(:);
h2 = cdfplot(Y);
axis([20,80,0,1])
% set(gca,'YTick',[0:10:500])
% legend('DGR','OSPF');
xlabel ('delay')
ylabel ('CDF');